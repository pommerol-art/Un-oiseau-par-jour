# Un oiseau par jour : projet APK (Capacitor)

## À installer une seule fois
- Node.js 20 ou plus récent : https://nodejs.org
- Android Studio (inclut le SDK Android et Java) : https://developer.android.com/studio

## Fabriquer l'APK
Dans ce dossier, dans un terminal :

    npm install
    npx cap add android
    npx cap sync
    npx cap open android

Dans Android Studio : menu Build > Build Bundle(s) / APK(s) > Build APK(s).
Le fichier se trouve ensuite dans android/app/build/outputs/apk/debug/app-debug.apk

## L'installer sur le téléphone
Copie app-debug.apk sur le téléphone, ouvre-le et autorise « installer des applications inconnues ».

## Modifier l'appli
Tout le code est dans www/index.html. Après une modification : npx cap sync, puis refaire le build.
Les photos et textes détaillés viennent de Wikipédia (connexion Internet nécessaire la première fois, puis mis en cache).
